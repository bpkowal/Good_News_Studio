"""One bounded native review round; immutable world, attributed revisions."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

from logic_puzzles_frameworks import RecordedModel, fingerprint
from run_logic_puzzles import project_conflicts, write_graph


def close_deontological_map(response):
    """Render the duplicate display map from typed duties, without changing them."""
    result = deepcopy(response)
    try:
        raw = result['choices'][0]['text']
        data = json.loads(raw)
    except (KeyError, IndexError, TypeError, json.JSONDecodeError):
        return result, None
    duties, display = data.get('dp'), data.get('fm')
    if not isinstance(duties, dict) or not duties or not isinstance(display, dict):
        return result, None
    rendered = {}
    for action, duty in duties.items():
        if not isinstance(duty, dict) or not all(isinstance(duty.get(key), str) for key in ('v', 'n', 'dt', 'rel', 'rs')):
            return result, None
        rendered[action] = (duty['v'] + ': duty ' + duty['dt'] + ' under ' + duty['n'] +
                            '; relation ' + duty['rel'] + '; ' + duty['rs'])
    if set(rendered) != set(display):
        return result, None
    data['fm'] = rendered
    result['choices'][0]['text'] = json.dumps(data)
    return result, {'method': 'DISPLAY_MAP_FROM_TYPED_DUTY_ASSESSMENTS',
                    'changed_fields': ['fm'], 'before': display, 'after': rendered,
                    'semantic_fields_changed': False}


def candidate_maxim_review(candidate, world=None):
    """Local argument context; never a reconstruction of the actor's intentions."""
    records = (candidate.get('committed_native_ledger') or {}).get('records', [])
    if not records:
        records = [{'canonical_action_id': action, 'candidate_maxim': row.get('mx'),
                    'means_relation': row.get('mr'), 'verdict': row.get('v'), 'reason': row.get('rs')}
                   for action, row in (candidate.get('authored_duty_proposal') or {}).get('duties', {}).items()
                   if isinstance(row, dict)]
    return {
        'origin': 'CANDIDATE_INTERPRETATION',
        'world_fact': False,
        'options': [{'action_id': row.get('canonical_action_id'),
                     'candidate_maxim': deepcopy(row.get('candidate_maxim')),
                     'means_relation': row.get('means_relation'),
                     'proposed_verdict': row.get('proposed_verdict', row.get('verdict')),
                     'reason': row.get('reason')}
                    for row in records],
        'world_references': {
            'origin': 'FROZEN_WORLD_COPY',
            'effects': [{key: e.get(key) for key in ('effect_id', 'action_id', 'outcome', 'polarity')}
                        for e in (world or {}).get('effects', [])],
            'relations': [{key: e.get(key) for key in ('action_id', 'source_id', 'relation', 'target_id')}
                          for e in (world or {}).get('causal_links', [])],
        },
        'question': (
            'For each option, including omission, state or revise its candidate maxim. '
            'Identify the exact step from purpose and chosen means to the claimed duty priority. '
            'For any proposed use of a person, identify the sought end, the belief that '
            'employing that person furthers it, and the decision to employ the person for it. '
            'Distinguish operating a device or redirecting a threat from employing its victim. '
            'Check means_effect_ids against end_effect_ids: a sibling harmful outcome is not '
            'a means to rescue just because both result from the same intervention. '
            'If the burden is a foreseen side effect, explain any claim that the person is '
            'nevertheless used merely as a means, or retract that inference. If intended use '
            'is claimed, explain its role in the proposed practical reasoning and the consent '
            'constraint; external causal necessity alone does not establish the actor\'s reasoning. '
            'Challenge whether the omission policy adequately answers the rescue claim. '
            'Examine universalization of the particular policy, not merely a benevolent purpose. '
            'Keep action permissibility separate from the moral quality of the maxim. '
            'A supported causal contribution does not by itself establish wrongful killing '
            'or settle the priority of a perfect duty. Defend that normative step separately. '
            'Do not assert unknown intentions or consent as world facts. Defend, revise, '
            'or explicitly leave the inference unresolved; a RESOLVED label cannot retire it.'),
    }


def review_jobs(assessment, issue_ids=None):
    graph = project_conflicts(assessment)
    nodes = {n['id']: n for n in graph['nodes']}
    groups = {}
    for issue_id in (graph['review_queue'] if issue_ids is None else issue_ids)[:2]:
        issue = nodes[issue_id]
        groups.setdefault(issue['origin'], []).append(issue)
    jobs = []
    for origin, issues in groups.items():
        claim_ids = {ident for issue in issues for ident in issue['claim_ids']}
        related = set(claim_ids)
        for edge in graph['edges']:
            if edge['kind'] in {'SUPPORT', 'DEPENDENCY'} and (edge['target'] in claim_ids or edge['source'] in claim_ids):
                related.update((edge['source'], edge['target']))
        # Group questions about one framework to avoid competing rewrites of
        # the same native record. Native qa supplies one answer to this bundle.
        jobs.append({'framework': origin, 'issue_id': 'CHALLENGE:' + fingerprint([i['id'] for i in issues])[:16],
                     'prior_selection_status': next(c.get('selection_status') for c in assessment['cycles'][-1]['candidates'] if c['specialist'] == origin),
                     'issues': deepcopy(issues), 'claims': [deepcopy(nodes[i]) for i in sorted(claim_ids)],
                     'support_and_dependencies': [deepcopy(nodes[i]) for i in sorted(related - claim_ids)],
                     'question': 'Review each of these objections separately in your answer: ' +
                     '; '.join(i['label'] for i in issues) +
                     '. Identify any native classification you revise, retain, or leave unresolved. '
                     'A missing factual link remains missing; a framework commitment cannot supply it.'})
    for job in jobs:
        if job['framework'] == 'deontological':
            prior = next(c for c in assessment['cycles'][-1]['candidates']
                         if c['specialist'] == 'deontological')
            job['maxim_review'] = candidate_maxim_review(
                prior, (assessment.get('action_source_grounding') or {}).get('world_model'))
            job['question'] += ' ' + job['maxim_review']['question']
            from deontology_rule_attention import source_rule_context, rule_attention_instruction
            job['source_rules'] = source_rule_context(
                (assessment.get('action_source_grounding') or {}).get('world_model', {}))
            job['question'] += ' ' + rule_attention_instruction(job['source_rules'])
            job['question'] += (' Explain why POSSIBLE staff exposure warrants the claimed perfect-duty '
                                'violation; do not upgrade risk to settled injury. Keep institutional '
                                'authority, emergency rescue, and foreseen side effects distinct.')
    return jobs


def residual_issue_ids(graph, attempted_origins):
    groups = {}
    for node in graph['nodes']:
        if (node.get('status') == 'OPEN' and node.get('kind') == 'UNRESOLVED_CONFLICT'
                and node.get('origin') not in attempted_origins):
            groups.setdefault(node['origin'], []).append(node['id'])
    # A bounded second round serves the most neglected remaining bundle,
    # rather than letting insertion order repeatedly select the first origin.
    if not groups:
        return []
    owner = sorted(groups, key=lambda origin: (-len(groups[origin]), origin))[0]
    return groups[owner][:2]


def reconcile(assessment, jobs, review_candidates, local_ledgers):
    """Replace only admitted owned proposals; preserve failed attempts separately."""
    result = deepcopy(assessment)
    original = assessment['cycles'][-1]['candidates']
    candidates = deepcopy(original)
    records = []
    for job in jobs:
        origin = job['framework']
        proposed = review_candidates.get(origin)
        ledger = (proposed or {}).get('committed_native_ledger') or {}
        response = (proposed or {}).get('challenge_response') or {}
        prior = next(c for c in original if c['specialist'] == origin)
        native_rejected = bool(proposed and ledger == prior.get('committed_native_ledger') and
            any(str(w).startswith('rejected update:') for w in proposed.get('framework_validation_errors', [])))
        old_ids = {r.get('assessment_node_id') for r in (prior.get('committed_native_ledger') or {}).get('records', []) if r.get('assessment_node_id')}
        new_ids = {r.get('assessment_node_id') for r in ledger.get('records', []) if r.get('assessment_node_id')}
        accepted = bool(proposed and old_ids <= new_ids and proposed.get('specialist') == origin and proposed.get('schema_valid') and
                        ledger.get('transaction_status') in {'COMMITTED', 'COMMITTED_WITH_UNCERTAINTY'} and
                        response.get('issue_id') == job['issue_id'] and not native_rejected)
        if accepted:
            candidates = [deepcopy(proposed) if c['specialist'] == origin else c for c in candidates]
            result['framework_proposition_ledgers'][origin] = deepcopy(local_ledgers[origin])
        for issue in job['issues']:
            related_claims = [c for c in job['claims'] if c['id'] in issue['claim_ids']]
            claim = next((c for c in related_claims if issue['label'].startswith(
                str(c['record'].get('canonical_action_id'))+' ')), related_claims[0])
            old = claim['record']
            nonoperative = claim.get('kind') == 'PROPOSED_ARGUMENT'
            replacements = deepcopy(ledger.get('records', [])) if nonoperative else [r for r in ledger.get('records', [])
                            if r.get('assessment_node_id') == old.get('assessment_node_id')]
            retained_error = any(issue['label'] in r.get('calibration_errors', []) for r in replacements)
            changes = [{field: {'before': old.get(field), 'after': row.get(field)}
                        for field in sorted(set(old) | set(row))
                        if old.get(field) != row.get(field)} for row in replacements]
            substantive = any(set(change) - {'calibration_errors', 'calibration_issues', 'provenance', 'cycle', 'epistemic_status'} for change in changes)
            if 'counts' in issue['label'] or 'numbers' in issue['label']:
                substantive = substantive or any(prior.get(key) != (proposed or {}).get(key)
                    for key in ('care_numerical_role', 'care_numerical_justification',
                                'framework_numerical_role', 'framework_numerical_justification'))
            if 'competing Care claim remains contested' in issue['label']:
                answer = str(response.get('answer', ''))
                competing_claim = str(old.get('competing_care_claim', ''))
                substantive = bool(substantive and competing_claim and len(answer.split()) >= 12
                    and competing_claim.casefold() in answer.casefold()
                    and any(row.get('reason') != old.get('reason') for row in replacements))
            warning_present = any(issue['label'] in str(w) for w in (proposed or {}).get('framework_validation_errors', []))
            removed = bool(accepted and replacements and substantive and (
                issue['conflict_type'] == 'UNSUPPORTED_INFERENCE' and not retained_error
                or issue['conflict_type'] == 'NATIVE_FRAMEWORK_WARNING' and not warning_present
                or issue['conflict_type'] == 'UNADMITTED_ARGUMENT' and not warning_present))
            unresolved_fields = [{field: value for field, value in row.items()
                                  if isinstance(value, str) and value in {'UNRESOLVED', 'CONTESTED', 'UNCERTAIN', 'UNKNOWN'}}
                                 for row in replacements]
            records.append({'original_issue_id': issue['id'], 'bundle_issue_id': job['issue_id'],
                            'framework': origin, 'objection': issue['label'],
                            'original_claim_id': claim['id'], 'original_record': deepcopy(old),
                            'proposed_records': deepcopy(replacements),
                            'review_status': 'RECONCILED' if accepted else
                                'RETAINED_AFTER_NATIVE_REJECTION' if native_rejected else 'REJECTED_OR_UNAVAILABLE',
                            'objection_check': 'NO_LONGER_REPORTED_BY_NATIVE_VALIDATOR' if removed else 'OPEN',
                            'semantic_resolution': 'NOT_INDEPENDENTLY_VERIFIED',
                            'classification_changes': changes,
                            'remaining_unresolved_fields': unresolved_fields,
                            'framework_validation_errors': deepcopy((proposed or {}).get('framework_validation_errors', [])),
                            'response': deepcopy(response),
                            'recommendation_before': prior.get('recommended_action'),
                            'recommendation_after': proposed.get('recommended_action') if accepted else prior.get('recommended_action')})
    result['cycles'].append({'cycle': 2, 'phase': 'TARGETED_REVIEW', 'candidates': candidates})
    result['targeted_review'] = {'rounds': 1, 'issues': records,
                                'proposal_attempts': deepcopy(review_candidates),
                                'framework_changes': {job['framework']: {
                                    key: {'before': prior.get(key), 'after': proposed.get(key)}
                                    for key in sorted(set(prior) | set(proposed))
                                    if prior.get(key) != proposed.get(key)}
                                    for job in jobs
                                    for prior in [next(c for c in original if c['specialist'] == job['framework'])]
                                    for proposed in [review_candidates.get(job['framework'], {})]},
                                'world_mutation': False, 'judgment_status': 'NOT_ADJUDICATED'}
    return result


def write_review(result, output_dir):
    output_dir = Path(output_dir)
    (output_dir/'targeted_review.json').write_text(json.dumps(result, indent=2)+'\n')
    graph = project_conflicts(result)
    rounds = result['targeted_review'].get('rounds', 1)
    graph['limits'][0] = f'{rounds} bounded targeted review round(s) completed; no collective judgment.'
    write_graph(graph, output_dir)
    lines = ['# Targeted framework review', '',
             f'{rounds} round(s), at most two objections per round. Native revisions remain attributed; the shared world is unchanged.', '',
             'Execution modes: ' + json.dumps(result['targeted_review'].get('execution_modes', {})) + '.', '',
             'Acceptance path: ' + result['targeted_review'].get('acceptance_path', 'see native trace') + '.', '',
             'Removing a validator objection is not independent proof of semantic correctness.', '']
    offer=result.get('follow_up_offer') or {}
    if offer.get('status')=='AVAILABLE':
        lines += ['## Optional deeper review', '', offer['message'], '',
                  'This asks about the revised argument; it does not establish a contradiction or authorize further API calls.', '']
        lines += [q['question']+'\n' for q in offer['questions']]
    for issue in result['targeted_review']['issues']:
        lines += ['## ' + issue['objection'], '',
                  'Framework: ' + issue['framework'] + '. Review: ' + issue['review_status'] + '.', '',
                  'Objection check: ' + issue['objection_check'] + '.', '',
                  'Recommendation: ' + str(issue['recommendation_before']) + ' → ' + str(issue['recommendation_after']), '',
                  'Reviewer answer: ' + issue['response'].get('answer', 'No admitted response.'), '',
                  'Follow-up: ' + issue['response'].get('follow_up_question', 'unresolved'), '',
                  'All native record changes and remaining uncertainty:', '', '```json',
                  json.dumps({'changes': issue['classification_changes'],
                              'unresolved': issue['remaining_unresolved_fields'],
                              'native_warnings': issue['framework_validation_errors']}, indent=2), '```', '',
                  'Original record and proposed replacement:', '', '```json',
                  json.dumps({'original': issue['original_record'], 'proposed': issue['proposed_records']}, indent=2), '```', '']
    lines += ['Residual claims and conflicts: [graph](conflict_graph.md).', '']
    if result['targeted_review'].get('retained_proposals'):
        lines += ['## Disputed full proposals', '',
                  'These remain attributed and nonoperative. No conclusion is promoted to the shared world.', '',
                  '```json', json.dumps(result['targeted_review']['retained_proposals'], indent=2), '```', '']
    if result['targeted_review'].get('isolated_classification_reviews'):
        lines += ['## Isolated native revalidation', '', '```json',
                  json.dumps(result['targeted_review']['isolated_classification_reviews'], indent=2), '```', '']
    for name, changes in result['targeted_review'].get('framework_changes', {}).items():
        lines += ['## All changed fields: ' + name, '', '```json',
                  json.dumps(changes, indent=2), '```', '']
    (output_dir/'targeted_review.md').write_text('\n'.join(lines))


def review(assessment_path, output_dir, backend_factory, *, tokens=3072, max_calls=2, allow_partial=True, allow_residual=True, issue_ids=None,
           jobs_override=None, prior_responses=None, verify_prior=False):
    from global_workspace.engine import WorkspaceEngine, WorkspaceConfig
    from global_workspace.frozen_world_replay import load_frozen_world_trace
    from global_workspace.local_specialists import CompactLocalSpecialist, extract_scenario_facts
    from global_workspace.models import WorkspaceBroadcast
    assessment_path, output_dir = Path(assessment_path), Path(output_dir)
    source_bytes = assessment_path.read_bytes()
    assessment = json.loads(source_bytes)
    from deontology_rule_attention import authored_duty_proposal, source_rule_context
    for candidate in assessment.get('cycles', [])[-1]['candidates']:
        if candidate['specialist'] == 'deontological' and not candidate.get('authored_duty_proposal'):
            path = assessment_path.parent/'deontological/model_calls.json'
            if path.exists():
                candidate['authored_duty_proposal'] = authored_duty_proposal(json.loads(path.read_text()))
    shared = json.loads((assessment_path.parent/'shared_input.json').read_text())
    quotes = json.loads((assessment_path.parent/'framework_commitments.json').read_text())
    from parliament_run_provenance import record_resource
    record_resource(assessment_path.parent/'shared_input.json')
    record_resource(assessment_path.parent/'framework_commitments.json')
    if fingerprint(shared) != assessment['shared_input_sha256'] or shared['scenario'] != assessment['scenario'] or shared['action_source_grounding'] != assessment['action_source_grounding']:
        raise ValueError('Review shared input differs from assessed input')
    output_dir.mkdir(parents=True, exist_ok=True)
    # Discovery only: local repair is a separate, nonvoting staging path.
    # Do not enlarge the full-review prompt or grant model-authored permissions.
    from deontology_repair_cards import build_cards
    repair_cards = []
    for candidate in assessment.get('cycles', [])[-1]['candidates']:
        if candidate['specialist'] == 'deontological':
            repair_cards.extend(c.to_dict() for c in build_cards(
                shared['action_source_grounding']['world_model'],
                candidate.get('committed_native_ledger') or {}))
    (output_dir/'derivation_repair_cards.json').write_text(
        json.dumps({'operative':False, 'cards':repair_cards}, indent=2)+'\n')
    replay_payload = deepcopy(assessment)
    replay_payload['canonical_action_records'] = deepcopy(shared['canonical_action_records'])
    replay_path = output_dir/'frozen_review_input.json'
    replay_path.write_text(json.dumps(replay_payload, indent=2)+'\n')
    replay = load_frozen_world_trace(replay_path, expected_scenario=assessment['scenario'])
    if len(replay.canonical_actions) != 2:
        raise ValueError('Targeted review pilot requires exactly two actions')
    jobs = deepcopy(jobs_override) if jobs_override is not None else review_jobs(assessment, issue_ids)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir/'review_jobs.json').write_text(json.dumps(jobs, indent=2)+'\n')
    source_graph = project_conflicts(assessment)
    write_graph(source_graph, output_dir/'before')
    attempts, ledgers, execution_modes = {}, {}, {}
    retained_proposals, partial_reviews = [], []
    for job in jobs:
        name = job['framework']
        prior = next(c for c in assessment['cycles'][-1]['candidates'] if c['specialist'] == name)
        recovery = not str((prior.get('committed_native_ledger') or {}).get('transaction_status', '')).startswith('COMMITTED')
        folder = output_dir/name
        folder.mkdir(parents=True, exist_ok=True)
        print('Targeted review: ' + name + ' (' + str(len(job['issues'])) + ' objections)...', flush=True)
        prior_calls = assessment_path.parent/name/'model_calls.json'
        saved_calls = json.loads(prior_calls.read_text()) if prior_calls.exists() else []
        saved = deepcopy((prior_responses or {}).get(name)) or next(
            (c.get('response') for c in reversed(saved_calls) if c.get('response') is not None), None)
        if saved is None:
            (folder/'prior_state_problem.json').write_text(json.dumps({
                'status': 'PRIOR_REPLAY_UNAVAILABLE', 'framework': name,
                'retained_original': True}, indent=2)+'\n')
            continue
        model = RecordedModel(backend_factory(name), replay.scenario, folder/'model_calls.json', review_context=job,
                              source_rules=source_rule_context(shared['action_source_grounding']['world_model']) if name == 'deontological' else None,
                              response_normalizer=close_deontological_map if name == 'deontological' else None,
                              max_calls=max_calls)
        execution_modes[name] = getattr(model.backend, 'execution_mode', 'MODEL_BACKEND')
        class PriorThenReview:
            reviewing = False
            seeded = False
            def complete_json(self, prompt, **kwargs):
                if self.reviewing:
                    return model.complete_json(prompt, **kwargs)
                if self.seeded:
                    raise RuntimeError('Prior native ledger could not be replayed without repair')
                self.seeded = True
                response = deepcopy(saved)
                if name == 'deontological':
                    response, _ = close_deontological_map(response)
                (folder/'prior_replay.json').write_text(json.dumps({
                    'origin': 'SAVED_PRIOR_RESPONSE', 'response': saved,
                    'response_sha256': fingerprint(saved), 'new_model_call': False}, indent=2)+'\n')
                return response
        staged = PriorThenReview()
        if recovery:
            staged.reviewing = True
            (folder/'prior_replay.json').write_text(json.dumps({
                'origin': 'SAVED_UNADMITTED_RESPONSE_CONTEXT_ONLY', 'response': saved,
                'response_sha256': fingerprint(saved), 'new_model_call': False,
                'seeded_as_operative': False}, indent=2)+'\n')
        specialist = CompactLocalSpecialist(name, staged, max_tokens=tokens,
            scenario_facts=extract_scenario_facts(replay.scenario),
            source_construction_advisory=deepcopy(replay.source_construction_advisory),
            canonical_action_records=deepcopy(shared['canonical_action_records']),
            core_quote_pack=deepcopy(quotes.get(name, {})))
        agenda = {'issue_id': job['issue_id'], 'question': job['question'],
                  'generated_by': 'NATIVE_LEDGER_CALIBRATION_REVIEW', 'about_specialist': name,
                  'target_specialists': [name], 'challenge_kind': 'INFERENCE',
                  'grounding_status': 'ATTRIBUTED_OBJECTION', 'raised_by': ''}
        class NativeReviewEngine(WorkspaceEngine):
            def prepare_cycle_input(self, **kwargs):
                if kwargs['cycle_number'] == (1 if recovery else 2):
                    if verify_prior and not recovery:
                        from global_workspace.deontology_ledger import committed_deontological_assessments
                        fields=('canonical_action_id','norm','verdict','relation','duty_type','harm_relation',
                                'means_relation','governing_norm','priority_basis','priority_rule','candidate_maxim')
                        prior=next(c for c in assessment['cycles'][-1]['candidates'] if c['specialist']==name)
                        expected=(prior.get('committed_native_ledger') or {}).get('records',[])
                        actual=committed_deontological_assessments(kwargs['graph_store'].graph)
                        signature=lambda rows: sorted([{f:r.get(f) for f in fields} for r in rows],
                                                      key=lambda r:str(r['canonical_action_id']))
                        if signature(actual)!=signature(expected):
                            raise RuntimeError('Prior reply does not reproduce the admitted revised argument; no follow-up call made')
                    staged.reviewing = True
                    kwargs['broadcast'] = WorkspaceBroadcast(constraint='PROPOSAL_REVIEW',
                        challenge_agenda=(deepcopy(agenda),))
                    (folder/'prior_framework_state.json').write_text(json.dumps({
                        'prior_framework_state': deepcopy(specialist.previous_framework_state),
                        'prior_candidate': next(c for c in assessment['cycles'][-1]['candidates'] if c['specialist'] == name),
                        'review_constraint': 'PROPOSAL_REVIEW'}, indent=2)+'\n')
                return super().prepare_cycle_input(**kwargs)
        engine = NativeReviewEngine([specialist], WorkspaceConfig(max_cycles=1 if recovery else 2, high_urgency_cycles=2,
            min_valid_specialists=1, stop_redundant_consensus_cycles=False, max_cycle_extensions=0,
            enable_synthesis=False, enable_planning=False, enable_consensus_audit=False,
            enable_problem_state_audit=False, enable_reversal_audit=False))
        native = engine.run(replay.scenario, list(replay.canonical_actions),
            scenario_facts=deepcopy(specialist.scenario_facts),
            source_action_legend=deepcopy(replay.source_action_legend),
            action_source_grounding=deepcopy(replay.action_source_grounding),
            presentation_actions=list(replay.presentation_actions),
            canonical_action_records=deepcopy(shared['canonical_action_records'])).to_dict()
        (folder/'native_trace.json').write_text(json.dumps(native, indent=2)+'\n')
        if native['action_source_grounding']['world_model'] != replay.action_source_grounding['world_model']:
            raise RuntimeError('Targeted review changed admitted world')
        if len(native['cycles']) >= (1 if recovery else 2):
            attempts[name] = native['cycles'][-1]['candidates'][0]
            ledgers[name] = native['proposition_ledger']
        interim = reconcile(assessment, [job], attempts, ledgers)
        rejected = any(i['review_status'] == 'RETAINED_AFTER_NATIVE_REJECTION'
                       for i in interim['targeted_review']['issues'])
        if rejected and model.calls and model.calls[-1].get('response'):
            raw = deepcopy(model.calls[-1]['response'])
            retained_proposals.append({'framework': name, 'issue_id': job['issue_id'],
                'status': 'DISPUTED_NONOPERATIVE', 'response': raw,
                'native_attempt': deepcopy(attempts[name]),
                'world_state_authority': 'NONE', 'semantic_support': 'NOT_INDEPENDENTLY_VERIFIED'})
            if allow_partial:
                from logic_puzzles_partial_review import isolate_classifications, IsolatedReplay
                isolated, patches = isolate_classifications(saved, raw, job)
                if isolated is not None:
                    partial_folder = folder/'isolated_classifications'
                    partial = review(assessment_path, partial_folder,
                        lambda owner: IsolatedReplay(isolated), tokens=tokens, max_calls=1,
                        allow_partial=False, allow_residual=False, issue_ids=[i['id'] for i in job['issues']])
                    accepted_partial = all(i['review_status'] == 'RECONCILED'
                        for i in partial['targeted_review']['issues'] if i['framework'] == name)
                    partial_reviews.append({'framework': name, 'patches': patches,
                        'response': isolated, 'source_response_sha256': fingerprint(raw),
                        'native_accepted': accepted_partial, 'new_api_calls': 0,
                        'path': str(partial_folder), 'full_bundle_accepted': False})
                    if accepted_partial:
                        attempts[name] = next(c for c in partial['cycles'][-1]['candidates'] if c['specialist'] == name)
                        ledgers[name] = partial['framework_proposition_ledgers'][name]
        result = reconcile(assessment, jobs, attempts, ledgers)
        write_review(result, output_dir)
    result = reconcile(assessment, jobs, attempts, ledgers)
    result['targeted_review']['adapter_calls'] = {
        job['framework']: len(json.loads((output_dir/job['framework']/'model_calls.json').read_text()))
        if (output_dir/job['framework']/'model_calls.json').exists() else 0 for job in jobs}
    result['targeted_review']['acceptance_path'] = 'NATIVE_RECURRENT_PROPOSAL_REVIEW'
    result['targeted_review']['nonoperative_recovery_frameworks'] = [job['framework'] for job in jobs
        if not str((next(c for c in assessment['cycles'][-1]['candidates'] if c['specialist'] == job['framework']).get('committed_native_ledger') or {}).get('transaction_status', '')).startswith('COMMITTED')]
    result['targeted_review']['prior_replay_calls'] = {job['framework']: 1 if
        (output_dir/job['framework']/'prior_replay.json').exists() and
        job['framework'] not in result['targeted_review']['nonoperative_recovery_frameworks'] else 0 for job in jobs}
    result['targeted_review']['execution_modes'] = execution_modes
    result['targeted_review']['retained_proposals'] = retained_proposals
    result['targeted_review']['isolated_classification_reviews'] = partial_reviews
    for partial in partial_reviews:
        if partial['native_accepted']:
            patch_issue_ids = {p['issue_id'] for p in partial['patches']}
            for issue in result['targeted_review']['issues']:
                if issue['framework'] == partial['framework']:
                    issue['review_status'] = ('ISOLATED_CLASSIFICATION_ACCEPTED'
                        if issue['original_issue_id'] in patch_issue_ids else 'ORIGINAL_CLASSIFICATION_RETAINED')
    if assessment_path.read_bytes() != source_bytes:
        raise RuntimeError('Original assessment changed during review')
    attempted = {j['framework'] for j in jobs}
    remaining = residual_issue_ids(source_graph, attempted)
    if allow_residual and remaining:
        residual = review(assessment_path, output_dir/'residual_round', backend_factory,
            tokens=tokens, max_calls=max_calls, allow_partial=allow_partial,
            allow_residual=False, issue_ids=remaining[:2])
        owners = set(residual['targeted_review']['adapter_calls'])
        result['cycles'][-1]['candidates'] = [
            next(c for c in residual['cycles'][-1]['candidates'] if c['specialist'] == old['specialist'])
            if old['specialist'] in owners else old for old in result['cycles'][-1]['candidates']]
        for owner in owners:
            result['framework_proposition_ledgers'][owner] = residual['framework_proposition_ledgers'][owner]
        result['targeted_review']['issues'].extend(residual['targeted_review']['issues'])
        for key in ('adapter_calls', 'prior_replay_calls', 'execution_modes', 'framework_changes', 'proposal_attempts'):
            result['targeted_review'][key].update(residual['targeted_review'].get(key, {}))
        for key in ('retained_proposals', 'isolated_classification_reviews', 'nonoperative_recovery_frameworks'):
            result['targeted_review'][key].extend(residual['targeted_review'].get(key, []))
        result['targeted_review']['rounds'] = 2
    scheduled = {i['original_issue_id'] for i in result['targeted_review']['issues']}
    processed = {i['original_issue_id'] for i in result['targeted_review']['issues']
                 if result['targeted_review']['adapter_calls'].get(i['framework'], 0) > 0}
    result['targeted_review']['coverage'] = {'attempted_issue_ids': sorted(processed),
        'scheduled_issue_ids': sorted(scheduled),
        'scheduled_but_unattempted_issue_ids': sorted(scheduled - processed),
        'unattempted_issue_ids': [i for i in source_graph['open_conflicts'] if i not in processed],
        'maximum_issues_per_round': 2, 'maximum_rounds': 2 if allow_residual else 1,
        'maximum_calls_per_framework': max_calls,
        'total_adapter_calls': sum(result['targeted_review']['adapter_calls'].values())}
    from logic_puzzles_followup import followup_offer, save_resume_state
    result['follow_up_offer'] = followup_offer(result)
    save_resume_state(assessment_path, output_dir, result, shared, quotes)
    write_review(result, output_dir)
    from parliament_run_provenance import record_checkpoint
    record_checkpoint('review_recorded',artifacts=[output_dir/'targeted_review.json'])
    return result


def _main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trace', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--parliament-root', type=Path, required=True)
    parser.add_argument('--model', default='o3')
    parser.add_argument('--review-depth', choices=('standard','deep'), default='standard',
                        help='Deep opts in to follow-ups to revised arguments')
    parser.add_argument('--followup-rounds', type=int, choices=(1,2), default=2)
    parser.add_argument('--checkpoint-tag', action='append', help='Run label, inherited by child runs; repeatable')
    args = parser.parse_args(argv)
    from parliament_run_provenance import record_configuration, record_start
    record_configuration(args)
    record_start(args.output_dir)
    sys.path.insert(0, str(args.parliament_root.resolve()))
    from dotenv import load_dotenv
    from global_workspace.openai_backend import OpenAIWorkspaceLLM
    load_dotenv(Path('/Users/benjaminkowal/Documents/Python/Python Coding/RAGAIMODEL/.env'))
    backend = OpenAIWorkspaceLLM(args.model, timeout=120)
    backend.execution_mode = 'LIVE_OPENAI'
    review(args.trace, args.output_dir, lambda name: backend)
    if args.review_depth=='deep':
        from logic_puzzles_followup import deepen
        deepen(args.output_dir/'targeted_review.json',args.output_dir/'deeper_review',
               lambda name:backend,opt_in=True,max_rounds=args.followup_rounds)


def main(argv=None):
    from parliament_run_provenance import record_execution
    return record_execution(_main, argv, entrypoint='logic_puzzles_review.py', output_flag='--output-dir', defaults={'model':'o3','runtime_profile':'compact_frameworks'})

if __name__ == '__main__':
    main()
