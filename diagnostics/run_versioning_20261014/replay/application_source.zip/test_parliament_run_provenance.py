import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import zipfile
import parliament_run_provenance as provenance


class RunProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)

    def test_archive_includes_untracked_source_but_not_credentials_or_diagnostics(self):
        for name in ('tracked.py','new.py','.env','diagnostics/result.json'):
            file=self.root/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_text('original')
        def git(*args,**kwargs):
            if args[0]=='ls-files':return 'tracked.py\0new.py\0.env\0diagnostics/result.json\0'
            if args[0]=='status':return '?? new.py\0'
            return 'fixture'
        with mock.patch.object(provenance,'git',side_effect=git):
            snapshot,archive=provenance.source_snapshot(self.root)
        self.assertEqual(set(snapshot['source_files']),{'tracked.py','new.py'})
        self.assertTrue(snapshot['dirty'])
        import io
        with zipfile.ZipFile(io.BytesIO(archive)) as source:self.assertEqual(source.read('new.py'),b'original')

    def test_parent_child_integrity_and_source_bundle(self):
        output=self.root/'parent'
        def child(argv):
            provenance.record_start(output/'child')
            (output/'child'/'result.json').write_text('{}');return 0
        def parent(argv):
            provenance.record_start(output)
            provenance.record_execution(child,['--output',str(output/'child')],entrypoint='child',output_flag='--output')
            (output/'result.json').write_text('{}');return 0
        provenance.record_execution(parent,['--output',str(output)],entrypoint='parent',output_flag='--output')
        record=provenance.load_manifest(output/'run_manifest.json')
        nested=provenance.load_manifest(output/'child/run_manifest.json')
        self.assertEqual(nested['parent_run_id'],record['run_id'])
        self.assertTrue(provenance.verify_manifest(output/'run_manifest.json')['valid'])
        (output/'result.json').write_text('altered')
        self.assertFalse(provenance.verify_manifest(output/'run_manifest.json')['valid'])

    def test_exception_finalizes_and_preserves_source_without_env_secrets(self):
        output=self.root/'failure'
        def fail(argv):
            provenance.record_start(output)
            raise RuntimeError('message may contain a secret; do not record it')
        with mock.patch.dict(os.environ,{'OPENAI_API_KEY':'private-token'}):
            with self.assertRaises(RuntimeError):
                provenance.record_execution(fail,['--output',str(output),'--unknown','private-token'],entrypoint='fixture',output_flag='--output')
        text=(output/'run_manifest.json').read_text()
        self.assertNotIn('private-token',text)
        self.assertNotIn('message may contain',text)
        self.assertEqual(json.loads(text)['status'],'EXCEPTION')
        self.assertTrue(provenance.verify_manifest(output/'run_manifest.json')['valid'])

    def test_replay_has_unknown_original_and_own_identity(self):
        output=self.root/'replay'
        provenance.record_execution(lambda argv:0,['--output',str(output),'--replay',str(self.root/'historical')],entrypoint='run_parliament_demo.py',output_flag='--output')
        record=provenance.load_manifest(output/'run_manifest.json')
        self.assertEqual(record['inputs']['replay_origin']['status'],'UNKNOWN_HISTORICAL')
        self.assertEqual(record['execution_path'],'saved_replay')
        self.assertEqual(record['mode'],'SAVED_REPLAY_NO_API')

    def test_revision_keeps_input_and_original_generation(self):
        report=self.root/'DEMO_REPORT.json';report.write_text('{"generation":"old"}')
        def update(argv):report.write_text('{"generation":"old","view":"new"}');return 0
        provenance.record_execution(update,['--report',str(report),'--answers','saved.json'],entrypoint='run_parliament_decisions_topography.py',output_flag='--report',in_place=True)
        manifest=next(p for p in (self.root/'provenance').glob('run_*.json') if p.stem.count('_')==1)
        record=provenance.load_manifest(manifest)
        self.assertEqual(json.loads((manifest.parent/record['input_report_snapshot']['path']).read_text()),{'generation':'old'})
        self.assertTrue(provenance.verify_manifest(manifest)['valid'])

    def test_compare_distinguishes_configuration_and_rejects_unknown_version(self):
        paths=[]
        for model in ('first','second'):
            output=self.root/model
            provenance.record_execution(lambda argv:0,['--output',str(output),'--model',model],entrypoint='fixture',output_flag='--output')
            paths.append(output/'run_manifest.json')
        self.assertIn('configuration',provenance.compare_manifests(*paths)['differences'])
        paths[0].write_text('{"schema_version":"future"}')
        with self.assertRaises(ValueError):provenance.load_manifest(paths[0])


if __name__=='__main__':unittest.main()
